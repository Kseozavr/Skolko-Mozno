﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace WindowsFormsApp1
{
    public partial class UserControl1 : UserControl
    {
        public int PartnerId { get; set; }
        public UserControl1()
        {
            InitializeComponent();
            foreach (Control control in this.Controls)
            {
                control.Click += UserControl1_Click;
            }
        }
        public void SetData(string type, string partner, string director, string phone, string rating, string percent, int id)
        {
            label1.Text = type;
            label2.Text = partner;
            label3.Text = director;
            label4.Text = phone;
            label5.Text = rating;
            label6.Text = percent;
            PartnerId = id;
        }
        private void UserControl1_Click(object sender, EventArgs e)
        {
            Form3 form = new Form3(PartnerId);
            form.Show();
            this.FindForm().Hide();
        }
    }
}