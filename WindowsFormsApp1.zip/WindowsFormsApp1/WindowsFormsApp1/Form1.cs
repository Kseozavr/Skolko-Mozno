﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private readonly sykaEntities2 db = new sykaEntities2();
        public Form1()
        {
            InitializeComponent();
            // Настройка FlowLayoutPanel для прокрутки
            flowLayoutPanel1.AutoScroll = true;  // Включаем автоматическую прокрутку
            flowLayoutPanel1.WrapContents = false;  // Отключаем перенос элементов (чтобы шли строго вертикально)
            flowLayoutPanel1.FlowDirection = FlowDirection.TopDown;  // Элементы располагаются сверху вниз
        }
        private void LoadCards()
        {
            flowLayoutPanel1.Controls.Clear();
            foreach (var partner in db.Partner_.ToList())
            {
                var partnerType = db.TypeParther_
                    .FirstOrDefault(t => t.IDTypeParther == partner.IDTypeParther)?.TypeParther ?? "Не указан";
                var discount = CalculateDiscount(partner.IDParther.ToString());
                UserControl1 partnerCard = new UserControl1();
                partnerCard.SetData(
                    partnerType,
                    partner.NameParther,
                    partner.Director,
                    partner.Telephone.ToString(),
                    "Рейтинг: " + partner.Reiting,
                    discount + " %",
                    (int)partner.IDParther);

                flowLayoutPanel1.Controls.Add(partnerCard);
            }
        }
        // Метод расчёта скидки (используем `Sale` вместо `Sales`)
        private int CalculateDiscount(string partnerId)
        {
            int id = int.Parse(partnerId);
            var totalProducts = db.Sale_
                .Where(s => s.IDParther == id)
                .Sum(s => (int?)s.KolvoProduct) ?? 0;
            if (totalProducts < 10000) return 0;
            if (totalProducts < 50000) return 5;
            if (totalProducts < 300000) return 10;
            return 15;
        }
        // Переход на Form2 (добавление партнёра)
        private void button1_Click_1(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }
        // Закрытие приложения
        private void Form1_FormClosing_1(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
        private void Form1_Load_1(object sender, EventArgs e)
        {
            LoadCards();
        }
    }
}