﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        private readonly sykaEntities2 db = new sykaEntities2();
        private Partner_ currentPartner; // Убрали символ `$`
        public Form3(int partnerId)
        {
            InitializeComponent();
            currentPartner = db.Partner_.FirstOrDefault(p => p.IDParther == partnerId); // Используем `Partner`
        }
        private void Form3_Load_1(object sender, EventArgs e)
        {
            if (currentPartner == null)
            {
                MessageBox.Show("Партнёр не найден.");
                Close();
                return;
            }
            // Заполняем ComboBox типами партнёров
            comboBox1.Items.AddRange(db.TypeParther_.Select(t => t.TypeParther).ToArray());
            // Заполняем поля данными
            textBox2.Text = currentPartner.NameParther;
            comboBox1.SelectedItem = db.TypeParther_.FirstOrDefault(t => t.IDTypeParther == currentPartner.IDTypeParther)?.TypeParther;
            textBox3.Text = currentPartner.Director;
            textBox4.Text = currentPartner.ElPochta;
            textBox7.Text = currentPartner.INN?.ToString() ?? "";
            textBox6.Text = currentPartner.YrAdress;
            textBox7.Text = currentPartner.INN.HasValue ? currentPartner.INN.Value.ToString() : "";
            textBox8.Text = currentPartner.Reiting?.ToString();
        }
        // Кнопка "Сохранить"
        private void button1_Click_1(object sender, EventArgs e)
        {
            currentPartner.NameParther = textBox2.Text;
            currentPartner.IDTypeParther = db.TypeParther_.FirstOrDefault(t => t.TypeParther == comboBox1.SelectedItem.ToString())?.IDTypeParther ?? 0;
            currentPartner.Director = textBox3.Text;
            currentPartner.ElPochta = textBox4.Text;
            currentPartner.Telephone = float.TryParse(textBox5.Text, out float phone) ? phone : 0f;
            currentPartner.YrAdress = textBox6.Text;
            currentPartner.INN = double.TryParse(textBox7.Text, out double inn) ? (double?)inn : (double?)null;
            currentPartner.Reiting = int.TryParse(textBox8.Text, out var rating) ? rating : 0;
            db.SaveChanges();
            MessageBox.Show("Изменения сохранены.");
            Form1 mainForm = new Form1();
            mainForm.Show();
            this.Close();
        }
        // Кнопка "Назад"
        private void button2_Click_1(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Close();
        }
    }
}