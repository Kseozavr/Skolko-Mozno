﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        private readonly sykaEntities2 db = new sykaEntities2();
        public Form2()
        {
            InitializeComponent();
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox2.Text) ||
            string.IsNullOrWhiteSpace(textBox3.Text) ||
            string.IsNullOrWhiteSpace(textBox4.Text) ||
            string.IsNullOrWhiteSpace(textBox5.Text) ||
            string.IsNullOrWhiteSpace(textBox6.Text) ||
            string.IsNullOrWhiteSpace(textBox7.Text) ||
            string.IsNullOrWhiteSpace(textBox8.Text) ||
            comboBox1.SelectedIndex < 0)
            {
                MessageBox.Show("Заполните все обязательные поля!");
                return;
            }
            var result = MessageBox.Show("Добавить?", "Подтверждение", MessageBoxButtons.YesNo);
            if (result != DialogResult.Yes) return;

            // Создаём нового партнёра (используем `Partner` вместо `Partners`)
            Partner_ newPartner = new Partner_
            {
                NameParther = textBox2.Text,
                IDTypeParther = db.TypeParther_.FirstOrDefault(t => t.TypeParther == comboBox1.SelectedItem.ToString())?.IDTypeParther ?? 0,
                Director = textBox3.Text,
                ElPochta = textBox4.Text,
                Telephone = float.TryParse(textBox5.Text, out float phone) ? phone : 0f,
                YrAdress = textBox6.Text,
                INN = double.TryParse(textBox7.Text, out double inn) ? (double?)inn : (double?)null,
                Reiting = int.TryParse(textBox8.Text, out var rating) ? rating : 0
            };
            db.Partner_.Add(newPartner); // Добавляем в DbSet `Partner`
            db.SaveChanges();

            MessageBox.Show("Партнёр успешно добавлен.");
        }
        // Кнопка "Назад"
        private void button2_Click_1(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
        // Загрузка формы (заполнение ComboBox типами партнёров)
        private void Form2_Load_1(object sender, EventArgs e)
        {
            comboBox1.Items.AddRange(db.TypeParther_.Select(t => t.TypeParther).ToArray());
        }
    }
}